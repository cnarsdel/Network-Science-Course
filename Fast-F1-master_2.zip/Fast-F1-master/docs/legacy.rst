.. automodule:: fastf1.legacy
    :members:
    :undoc-members:
    :show-inheritance:


