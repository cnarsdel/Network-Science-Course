.. automodule:: fastf1.events

