.. automodule:: fastf1.livetiming
    :members:
    :undoc-members:
    :show-inheritance:
