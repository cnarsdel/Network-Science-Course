.. automodule:: fastf1.plotting
  :members:
  :show-inheritance:
