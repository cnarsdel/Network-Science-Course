
.. automodule:: fastf1

