.. automodule:: fastf1.utils
    :members:
    :show-inheritance:
